Lab 6 README Olivia Martens

Building off Lab 5 Application

Using a package to write to a csv file, json2csv
installed using $ npm install -g json2csv

Using json2csv makes it easiest to write to a csv in the Node server.js document. 

At the end of making this I started receiving an error that I had exceeded my connection limit for a user, and I'm not really sure how to fix that.
