Lab 1 Read Me

Started by changing the JSON file to a js file and using the JSON text as a js object (array).
Created html structure for the page using bootstrap

created js function to retrieve 5 tweets at a time and insert them into the DOM
used the setInterval function to run the function every 3 seconds

