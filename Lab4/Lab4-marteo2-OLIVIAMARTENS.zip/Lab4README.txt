Lab 4 README - Liv Martens

I created new HTML structure to bootstrap a new look, the HTML all works

My initial plan was to implement my Weather App code but to change out the animated ticker function for Angular ng-repeat code to simply repeat the element for each item in the weather forecast array. 
This implementation kept directing me to an error code for this issue -> https://github.com/angular/angular.js/issues/9692 
I'm not sure how to solve this, so I attempted implementation of angular to bind the latitude/longitude data to a dom element, this didn't really work either as it never updated with the variable values. Not sure how to fix?

I also implemented Flexbox styling for the CSS