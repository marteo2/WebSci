Lab 7 README Olivia Martens

Building off Lab 5 & 6 Application

Using a package to write to a csv file, json2csv
installed using $ npm install -g json2csv

Using json2csv makes it easiest to write to a csv in the Node server.js document. 

At the end of making this I started receiving an error that I had exceeded my connection limit for a user, and I'm not really sure how to fix that.


/// NOTES ON MONGODB

from C:\Program Files\MongoDB\Server\3.6\bin run mongod.exe before beginning
then run node server on location

Professor Ahmed helped me set up  my database to run with mongoose instead of mongodb, I have been told this is acceptable.

The database is running and recording tweet data, but it is only recording the text from the tweets and not the additional fields? I am unsure how to fix this. I will include a picture of my database output in compass.